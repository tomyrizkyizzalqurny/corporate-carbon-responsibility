********************************************************************************
* 12_FINAL_PATCH_Q1_v1.do
*
* FINAL PATCH — CARBON EMISSION Q1 ANALYSIS
* Indonesia vs United States | Non-financial firms | 2021–2024
*
* WHY THIS PATCH EXISTS
* ---------------------
* Final validation identified three remaining issues:
*   (1) higher-order imbalance, especially cash_ratio^2;
*   (2) RESET / linktest evidence of nonlinear functional form;
*   (3) the previous cluster bootstrap failed because resampled clusters
*       conflicted with the active xtset panel declaration.
*
* THIS PATCH:
*   A. re-estimates an enhanced nonlinear propensity/comparability model;
*   B. constructs bounded overlap weights from that model;
*   C. re-checks first- and second-moment balance + ESS;
*   D. estimates linear, quadratic, and restricted-cubic-spline outcome models;
*   E. runs corrected firm-cluster bootstrap;
*   F. runs a stronger TWO-STAGE cluster bootstrap that re-estimates the
*      propensity model and overlap weights inside every bootstrap replication;
*   G. optionally runs wild-cluster bootstrap if boottest is already installed;
*   H. exports one compact final comparison table.
*
* IMPORTANT
* ---------
* Country is a classification, NOT a manipulable treatment.
* Results must be described as adjusted/conditional country differences,
* not causal effects.
*
* REQUIRED INPUT — auto-detected in this order:
*   1. outputs_q1\final_validation\12_final_validated_sample_v1.dta
*   2. outputs_q1\11_analysis_master_ready_v1.dta
*   3. 12_final_validated_sample_v1.dta
*
* OUTPUT FOLDER:
*   outputs_q1\final_patch\
*
* MAIN OUTPUTS:
*   13_final_patch_validated_v1.dta
*   final_patch_models_v1.csv
*   qa_enhanced_balance_v1.csv
*   qa_enhanced_weights_v1.csv
*   qa_enhanced_categorical_balance_v1.csv
*   bootstrap_fixedweight_reps_v1.dta
*   bootstrap_twostage_reps_v1.dta
*   FINAL_PATCH_Q1_v1.log
*
* Stata 17+
********************************************************************************

version 17.0
clear all
set more off
set linesize 255
set seed 20260831

* Final run recommendation.
local BREPS 999

********************************************************************************
* 00. SETUP
********************************************************************************

capture mkdir "outputs_q1"
capture mkdir "outputs_q1\final_patch"
local OUT "outputs_q1\final_patch"

capture log close
log using "`OUT'\FINAL_PATCH_Q1_v1.log", text replace

display as text "=============================================================="
display as text "FINAL Q1 PATCH — START"
display as text "=============================================================="

local DATA ""

capture confirm file "outputs_q1\final_validation\12_final_validated_sample_v1.dta"
if !_rc local DATA "outputs_q1\final_validation\12_final_validated_sample_v1.dta"

if "`DATA'"=="" {
    capture confirm file "outputs_q1\11_analysis_master_ready_v1.dta"
    if !_rc local DATA "outputs_q1\11_analysis_master_ready_v1.dta"
}

if "`DATA'"=="" {
    capture confirm file "12_final_validated_sample_v1.dta"
    if !_rc local DATA "12_final_validated_sample_v1.dta"
}

if "`DATA'"=="" {
    display as error "INPUT NOT FOUND."
    display as error "Expected 12_final_validated_sample_v1.dta or 11_analysis_master_ready_v1.dta."
    log close
    exit 601
}

use "`DATA'", clear
display as result "Loaded: `DATA'"

isid firm_id year
xtset firm_id year
assert inrange(year,2021,2024)
assert is_financial==0
assert analysis_support==1 if !missing(ow_q1) & analysis_support==1

count if analysis_support==1
display as result "Original final comparable N = " r(N)

********************************************************************************
* 01. ENHANCED NONLINEAR PROPENSITY / COMPARABILITY MODEL
*
* Overlap weighting based on a logistic propensity model has an important
* balancing property: included covariate functions are targeted directly.
* Therefore we include BOTH first-order and quadratic covariate terms.
********************************************************************************

display as text "=============================================================="
display as text "01. ENHANCED NONLINEAR OVERLAP WEIGHTING"
display as text "=============================================================="

capture drop pscore_nl ow_nl

quietly logit indonesia ///
    c.ln_assets##c.ln_assets ///
    c.roa##c.roa ///
    c.tangibility##c.tangibility ///
    c.cash_ratio##c.cash_ratio ///
    i.year ///
    i.sector_id ///
    if analysis_support==1

predict double pscore_nl if e(sample), pr
label var pscore_nl "Enhanced nonlinear Indonesia propensity/comparability score"

assert pscore_nl>0 & pscore_nl<1 if e(sample)

gen double ow_nl = ///
    cond(indonesia==1,1-pscore_nl,pscore_nl) ///
    if e(sample)

label var ow_nl "Enhanced nonlinear overlap weight"

assert ow_nl>0 & ow_nl<1 if !missing(ow_nl)

summarize pscore_nl if indonesia==1 & analysis_support==1, detail
summarize pscore_nl if indonesia==0 & analysis_support==1, detail
summarize ow_nl if indonesia==1 & analysis_support==1, detail
summarize ow_nl if indonesia==0 & analysis_support==1, detail

********************************************************************************
* 02. EFFECTIVE SAMPLE SIZE OF ENHANCED WEIGHTS
********************************************************************************

display as text "=============================================================="
display as text "02. ENHANCED WEIGHT DIAGNOSTICS / ESS"
display as text "=============================================================="

tempname wpost
postfile `wpost' ///
    str16 country ///
    double n ps_min ps_p1 ps_p50 ps_p99 ps_max ///
           w_min w_p1 w_p50 w_p99 w_max sum_w ess ///
    using "`OUT'\qa_enhanced_weights_v1.dta", replace

foreach c in 0 1 {

    quietly count if analysis_support==1 & indonesia==`c' & !missing(ow_nl)
    scalar n_c=r(N)

    quietly summarize pscore_nl if analysis_support==1 & indonesia==`c', detail
    scalar psmin=r(min)
    scalar psp1=r(p1)
    scalar psp50=r(p50)
    scalar psp99=r(p99)
    scalar psmax=r(max)

    quietly summarize ow_nl if analysis_support==1 & indonesia==`c', detail
    scalar wmin=r(min)
    scalar wp1=r(p1)
    scalar wp50=r(p50)
    scalar wp99=r(p99)
    scalar wmax=r(max)
    scalar sw=r(mean)*r(N)

    tempvar sqw
    gen double `sqw'=ow_nl^2 if analysis_support==1 & indonesia==`c'
    quietly summarize `sqw' if analysis_support==1 & indonesia==`c', meanonly
    scalar sw2=r(mean)*r(N)
    drop `sqw'

    scalar ess=(sw^2)/sw2

    local cname = cond(`c'==1,"Indonesia","United States")

    post `wpost' ("`cname'") ///
        (n_c) (psmin) (psp1) (psp50) (psp99) (psmax) ///
        (wmin) (wp1) (wp50) (wp99) (wmax) (sw) (ess)
}
postclose `wpost'

preserve
    use "`OUT'\qa_enhanced_weights_v1.dta", clear
    export delimited using "`OUT'\qa_enhanced_weights_v1.csv", replace
restore

********************************************************************************
* 03. FIRST + SECOND MOMENT BALANCE
********************************************************************************

display as text "=============================================================="
display as text "03. ENHANCED BALANCE CHECK"
display as text "=============================================================="

capture drop q_ln_assets q_roa q_tangibility q_cash_ratio
gen double q_ln_assets   = ln_assets^2
gen double q_roa         = roa^2
gen double q_tangibility = tangibility^2
gen double q_cash_ratio  = cash_ratio^2

tempname bpost
postfile `bpost' ///
    str24 variable ///
    double mean_id_pre mean_us_pre smd_pre ///
           mean_id_post mean_us_post smd_post ///
           vr_pre vr_post ///
    using "`OUT'\qa_enhanced_balance_v1.dta", replace

foreach v in ///
    ln_assets roa tangibility cash_ratio ///
    q_ln_assets q_roa q_tangibility q_cash_ratio {

    * Unweighted.
    quietly summarize `v' if analysis_support==1 & indonesia==1
    scalar m1=r(mean)
    scalar v1=r(Var)

    quietly summarize `v' if analysis_support==1 & indonesia==0
    scalar m0=r(mean)
    scalar v0=r(Var)

    scalar smd0=(m1-m0)/sqrt((v1+v0)/2)
    scalar vr0=v1/v0

    * Enhanced overlap weighted.
    quietly summarize `v' if analysis_support==1 & indonesia==1 [aw=ow_nl]
    scalar wm1=r(mean)
    scalar wv1=r(Var)

    quietly summarize `v' if analysis_support==1 & indonesia==0 [aw=ow_nl]
    scalar wm0=r(mean)
    scalar wv0=r(Var)

    scalar smdw=(wm1-wm0)/sqrt((wv1+wv0)/2)
    scalar vrw=wv1/wv0

    post `bpost' ("`v'") ///
        (m1) (m0) (smd0) ///
        (wm1) (wm0) (smdw) ///
        (vr0) (vrw)
}
postclose `bpost'

preserve
    use "`OUT'\qa_enhanced_balance_v1.dta", clear

    gen abs_smd_pre=abs(smd_pre)
    gen abs_smd_post=abs(smd_post)
    gen byte pass_smd_010=abs_smd_post<.10
    gen byte pass_smd_020=abs_smd_post<.20

    order variable ///
        mean_id_pre mean_us_pre smd_pre abs_smd_pre ///
        mean_id_post mean_us_post smd_post abs_smd_post ///
        vr_pre vr_post pass_smd_010 pass_smd_020

    summarize abs_smd_post
    display as result "Maximum enhanced post-weight |SMD| = " %8.5f r(max)

    count if pass_smd_010==0
    if r(N)>0 {
        display as error "WARNING: one or more enhanced balance terms remain |SMD| >= 0.10."
    }
    else {
        display as result "BALANCE CHECK PASS: all included first/quadratic terms |SMD| < 0.10."
    }

    export delimited using "`OUT'\qa_enhanced_balance_v1.csv", replace
restore

********************************************************************************
* 04. CATEGORICAL BALANCE — YEAR + SECTOR
********************************************************************************

display as text "=============================================================="
display as text "04. YEAR / SECTOR BALANCE"
display as text "=============================================================="

tempname cpost
postfile `cpost' ///
    str16 family str32 category ///
    double prop_id prop_us abs_diff ///
    using "`OUT'\qa_enhanced_categorical_balance_v1.dta", replace

foreach yy of numlist 2021/2024 {
    tempvar dyear
    gen byte `dyear'=year==`yy' if analysis_support==1

    quietly summarize `dyear' if analysis_support==1 & indonesia==1 [aw=ow_nl]
    scalar py1=r(mean)

    quietly summarize `dyear' if analysis_support==1 & indonesia==0 [aw=ow_nl]
    scalar py0=r(mean)

    post `cpost' ("year") ("`yy'") (py1) (py0) (abs(py1-py0))
    drop `dyear'
}

levelsof sector_id if analysis_support==1, local(sectors)
foreach ss of local sectors {
    tempvar dsec
    gen byte `dsec'=sector_id==`ss' if analysis_support==1

    quietly summarize `dsec' if analysis_support==1 & indonesia==1 [aw=ow_nl]
    scalar ps1=r(mean)

    quietly summarize `dsec' if analysis_support==1 & indonesia==0 [aw=ow_nl]
    scalar ps0=r(mean)

    post `cpost' ("sector") ("sector_`ss'") (ps1) (ps0) (abs(ps1-ps0))
    drop `dsec'
}
postclose `cpost'

preserve
    use "`OUT'\qa_enhanced_categorical_balance_v1.dta", clear
    summarize abs_diff
    display as result "Maximum weighted year/sector proportion difference = " %9.6f r(max)
    export delimited using "`OUT'\qa_enhanced_categorical_balance_v1.csv", replace
restore

********************************************************************************
* 05. FINAL MODEL COMPARISON POSTFILE
********************************************************************************

tempname mpost
postfile `mpost' ///
    str38 model str28 specification ///
    double b se p ci_lo ci_hi nobs r2 ///
    using "`OUT'\final_patch_models_v1.dta", replace

********************************************************************************
* 06. M01 — ENHANCED OW, LINEAR OUTCOME MODEL
********************************************************************************

display as text "=============================================================="
display as text "06. ENHANCED OW LINEAR MODEL"
display as text "=============================================================="

quietly regress ln1p_s12_int ///
    indonesia ///
    ln_assets roa tangibility cash_ratio ///
    i.year i.sector_id ///
    if analysis_support==1 [pw=ow_nl], ///
    vce(cluster firm_id)

scalar b=_b[indonesia]
scalar se=_se[indonesia]
scalar p=2*ttail(e(df_r),abs(b/se))
scalar lo=b-invttail(e(df_r),.025)*se
scalar hi=b+invttail(e(df_r),.025)*se

post `mpost' ///
    ("M01_enhanced_OW_linear") ("cluster_firm") ///
    (b) (se) (p) (lo) (hi) (e(N)) (e(r2))

estimates store PATCH_M01

********************************************************************************
* 07. M02 — ENHANCED OW + QUADRATIC OUTCOME MODEL
*
* Directly addresses the RESET/linktest concern using flexible but parsimonious
* nonlinear covariate functions.
********************************************************************************

display as text "=============================================================="
display as text "07. ENHANCED OW QUADRATIC MODEL"
display as text "=============================================================="

quietly regress ln1p_s12_int ///
    indonesia ///
    c.ln_assets##c.ln_assets ///
    c.roa##c.roa ///
    c.tangibility##c.tangibility ///
    c.cash_ratio##c.cash_ratio ///
    i.year i.sector_id ///
    if analysis_support==1 [pw=ow_nl], ///
    vce(cluster firm_id)

scalar b=_b[indonesia]
scalar se=_se[indonesia]
scalar p=2*ttail(e(df_r),abs(b/se))
scalar lo=b-invttail(e(df_r),.025)*se
scalar hi=b+invttail(e(df_r),.025)*se

post `mpost' ///
    ("M02_enhanced_OW_quadratic") ("cluster_firm") ///
    (b) (se) (p) (lo) (hi) (e(N)) (e(r2))

estimates store PATCH_M02

display as text "----- RESET after quadratic specification -----"
capture noisily estat ovtest

display as text "----- Linktest after quadratic specification -----"
capture noisily linktest

********************************************************************************
* 08. M03 — RESTRICTED CUBIC SPLINE OUTCOME MODEL
*
* Flexible functional-form sensitivity. Four knots are used for each continuous
* covariate; country coefficient remains the target comparative parameter.
********************************************************************************

display as text "=============================================================="
display as text "08. ENHANCED OW RESTRICTED-CUBIC-SPLINE MODEL"
display as text "=============================================================="

capture drop rcs_lna*
capture drop rcs_roa*
capture drop rcs_tan*
capture drop rcs_cash*

mkspline rcs_lna = ln_assets, cubic nknots(4)
mkspline rcs_roa = roa, cubic nknots(4)
mkspline rcs_tan = tangibility, cubic nknots(4)
mkspline rcs_cash = cash_ratio, cubic nknots(4)

quietly regress ln1p_s12_int ///
    indonesia ///
    rcs_lna* ///
    rcs_roa* ///
    rcs_tan* ///
    rcs_cash* ///
    i.year i.sector_id ///
    if analysis_support==1 [pw=ow_nl], ///
    vce(cluster firm_id)

scalar b=_b[indonesia]
scalar se=_se[indonesia]
scalar p=2*ttail(e(df_r),abs(b/se))
scalar lo=b-invttail(e(df_r),.025)*se
scalar hi=b+invttail(e(df_r),.025)*se

post `mpost' ///
    ("M03_enhanced_OW_RCS") ("cluster_firm") ///
    (b) (se) (p) (lo) (hi) (e(N)) (e(r2))

estimates store PATCH_M03

display as text "----- RESET after spline specification -----"
capture noisily estat ovtest

display as text "----- Linktest after spline specification -----"
capture noisily linktest

********************************************************************************
* 09. M04 — INFLUENCE SENSITIVITY UNDER ENHANCED WEIGHTS
********************************************************************************

display as text "=============================================================="
display as text "09. ENHANCED WEIGHT INFLUENCE SENSITIVITY"
display as text "=============================================================="

* Cook's D comes from an unweighted diagnostic regression; it flags influence,
* but does not redefine the primary sample.
quietly regress ln1p_s12_int ///
    indonesia ///
    c.ln_assets##c.ln_assets ///
    c.roa##c.roa ///
    c.tangibility##c.tangibility ///
    c.cash_ratio##c.cash_ratio ///
    i.year i.sector_id ///
    if analysis_support==1

capture drop cook_patch high_cook_patch
predict double cook_patch if e(sample), cooksd

quietly _pctile cook_patch if e(sample), p(99)
scalar cook99=r(r1)

gen byte high_cook_patch=cook_patch>cook99 ///
    if analysis_support==1 & !missing(cook_patch)

quietly regress ln1p_s12_int ///
    indonesia ///
    c.ln_assets##c.ln_assets ///
    c.roa##c.roa ///
    c.tangibility##c.tangibility ///
    c.cash_ratio##c.cash_ratio ///
    i.year i.sector_id ///
    if analysis_support==1 & high_cook_patch==0 [pw=ow_nl], ///
    vce(cluster firm_id)

scalar b=_b[indonesia]
scalar se=_se[indonesia]
scalar p=2*ttail(e(df_r),abs(b/se))
scalar lo=b-invttail(e(df_r),.025)*se
scalar hi=b+invttail(e(df_r),.025)*se

post `mpost' ///
    ("M04_enhanced_OW_noTopCook") ("cluster_firm") ///
    (b) (se) (p) (lo) (hi) (e(N)) (e(r2))

********************************************************************************
* 10. CORRECTED FIXED-WEIGHT FIRM-CLUSTER BOOTSTRAP
*
* Key fix:
*   - clear xtset before cluster resampling;
*   - idcluster() assigns a new unique cluster ID to duplicated resampled firms.
********************************************************************************

display as text "=============================================================="
display as text "10. CORRECTED FIXED-WEIGHT CLUSTER BOOTSTRAP"
display as text "=============================================================="

xtset, clear

capture noisily bootstrap ///
    b_indonesia=_b[indonesia], ///
    reps(`BREPS') ///
    seed(20260831) ///
    cluster(firm_id) ///
    idcluster(bs_firm_fixed) ///
    nodots ///
    saving("`OUT'\bootstrap_fixedweight_reps_v1.dta", replace): ///
    regress ln1p_s12_int ///
        indonesia ///
        c.ln_assets##c.ln_assets ///
        c.roa##c.roa ///
        c.tangibility##c.tangibility ///
        c.cash_ratio##c.cash_ratio ///
        i.year i.sector_id ///
        if analysis_support==1 [pw=ow_nl]

local fixedboot_rc=_rc

if `fixedboot_rc'==0 {
    display as result "FIXED-WEIGHT CLUSTER BOOTSTRAP COMPLETE."
    capture noisily estat bootstrap, all
}
else {
    display as error "FIXED-WEIGHT CLUSTER BOOTSTRAP FAILED; inspect log."
}

********************************************************************************
* 11. TWO-STAGE CLUSTER BOOTSTRAP
*
* This is the stronger bootstrap:
* every replication RE-ESTIMATES:
*   (a) nonlinear propensity/comparability score,
*   (b) overlap weights,
*   (c) quadratic weighted outcome regression.
*
* Thus first-stage weighting uncertainty is propagated into the final
* country-coefficient uncertainty.
********************************************************************************

display as text "=============================================================="
display as text "11. TWO-STAGE RE-ESTIMATED-WEIGHT CLUSTER BOOTSTRAP"
display as text "=============================================================="

capture program drop q1_twostage_est
program define q1_twostage_est, rclass
    version 17.0

    tempvar ps_bs ow_bs

    capture quietly logit indonesia ///
        c.ln_assets##c.ln_assets ///
        c.roa##c.roa ///
        c.tangibility##c.tangibility ///
        c.cash_ratio##c.cash_ratio ///
        i.year ///
        i.sector_id ///
        if analysis_support==1

    if _rc {
        return scalar b=.
        exit
    }

    quietly predict double `ps_bs' if e(sample), pr

    quietly gen double `ow_bs'= ///
        cond(indonesia==1,1-`ps_bs',`ps_bs') ///
        if e(sample)

    capture quietly regress ln1p_s12_int ///
        indonesia ///
        c.ln_assets##c.ln_assets ///
        c.roa##c.roa ///
        c.tangibility##c.tangibility ///
        c.cash_ratio##c.cash_ratio ///
        i.year i.sector_id ///
        if analysis_support==1 & !missing(`ow_bs') [pw=`ow_bs']

    if _rc {
        return scalar b=.
        exit
    }

    return scalar b=_b[indonesia]
end

capture noisily bootstrap ///
    b_indonesia=r(b), ///
    reps(`BREPS') ///
    seed(20260901) ///
    cluster(firm_id) ///
    idcluster(bs_firm_twostage) ///
    reject(missing(r(b))) ///
    nodots ///
    saving("`OUT'\bootstrap_twostage_reps_v1.dta", replace): ///
    q1_twostage_est

local twoboot_rc=_rc

if `twoboot_rc'==0 {
    display as result "TWO-STAGE CLUSTER BOOTSTRAP COMPLETE."
    capture noisily estat bootstrap, all
}
else {
    display as error "TWO-STAGE CLUSTER BOOTSTRAP FAILED; inspect log."
}

capture program drop q1_twostage_est

********************************************************************************
* 12. OPTIONAL WILD-CLUSTER BOOTSTRAP
*
* With >1,000 firm clusters, cluster-robust asymptotics are already favorable.
* This is an OPTIONAL supplementary check when boottest is already installed.
********************************************************************************

display as text "=============================================================="
display as text "12. OPTIONAL WILD-CLUSTER BOOTSTRAP"
display as text "=============================================================="

capture which boottest

if !_rc {

    quietly regress ln1p_s12_int ///
        indonesia ///
        c.ln_assets##c.ln_assets ///
        c.roa##c.roa ///
        c.tangibility##c.tangibility ///
        c.cash_ratio##c.cash_ratio ///
        i.year i.sector_id ///
        if analysis_support==1 [pw=ow_nl], ///
        vce(cluster firm_id)

    capture noisily boottest indonesia, ///
        cluster(firm_id) ///
        reps(9999) ///
        seed(20260831)
}
else {
    display as text "boottest not installed. Optional wild-bootstrap check skipped."
    display as text "This does NOT invalidate the analysis because firm-cluster robust SE"
    display as text "and corrected cluster bootstrap are the primary inference checks."
}

********************************************************************************
* 13. RESTORE PANEL DECLARATION
********************************************************************************

xtset firm_id year

********************************************************************************
* 14. EXPORT FINAL MODEL COMPARISON
********************************************************************************

postclose `mpost'

preserve
    use "`OUT'\final_patch_models_v1.dta", clear

    gen double ratio_1plusY=exp(b)
    gen double pct_1plusY=(exp(b)-1)*100

    * pct_1plusY refers to the multiplicative scale of (1+Y);
    * do not automatically describe it as an exact percent change in Y.
    order model specification ///
        b se p ci_lo ci_hi ///
        ratio_1plusY pct_1plusY ///
        nobs r2

    sort model
    export delimited using "`OUT'\final_patch_models_v1.csv", replace
restore

********************************************************************************
* 15. SAVE PATCHED FINAL DATA
********************************************************************************

compress
sort firm_id year

label data ///
"Carbon Q1 final patch validated | enhanced OW + nonlinear + bootstrap | v1"

save "`OUT'\13_final_patch_validated_v1.dta", replace

********************************************************************************
* 16. FINAL CHECKLIST
********************************************************************************

display as text "=============================================================="
display as text "16. FINAL PATCH CHECKLIST"
display as text "=============================================================="

isid firm_id year
assert inrange(year,2021,2024)
assert is_financial==0
assert ow_nl>0 & ow_nl<1 if analysis_support==1

count if analysis_support==1
display as result "Final patch comparable firm-year N = " r(N)

egen byte tagfirm_patch=tag(firm_id) if analysis_support==1
count if tagfirm_patch==1
display as result "Final patch comparable firms = " r(N)
drop tagfirm_patch

display as text "--------------------------------------------------------------"
display as text "DECISION RULES FOR FINAL LOCK"
display as text "A. Enhanced first/quadratic balance: target |SMD| < 0.10."
display as text "B. Country coefficient should remain directionally stable across M01-M04."
display as text "C. Corrected cluster bootstrap should complete."
display as text "D. Two-stage cluster bootstrap should preferably complete."
display as text "E. RESET may remain statistically significant in a large N;"
display as text "   interpretation should emphasize coefficient stability under"
display as text "   quadratic and spline specifications rather than chasing p>0.05."
display as text "F. Country coefficient remains ASSOCIATIONAL / CONDITIONAL, not causal."
display as text "--------------------------------------------------------------"

display as text "=============================================================="
display as text "FINAL Q1 PATCH COMPLETE"
display as text "=============================================================="

display as result "Final model comparison:"
display as result "`OUT'\final_patch_models_v1.csv"

display as result "Enhanced balance:"
display as result "`OUT'\qa_enhanced_balance_v1.csv"

display as result "Enhanced weight diagnostics:"
display as result "`OUT'\qa_enhanced_weights_v1.csv"

display as result "Patched dataset:"
display as result "`OUT'\13_final_patch_validated_v1.dta"

display as result "Audit log:"
display as result "`OUT'\FINAL_PATCH_Q1_v1.log"

log close

********************************************************************************
* END
********************************************************************************
